<?php
/**
 * Plugin Name: WP i18n
 */
use Gettext\Translations;

/**
* Registers a new post type
* @uses $wp_post_types Inserts new post type object into the list
*
* @param string  Post type key, must not exceed 20 characters
* @param array|string  See optional args description above.
* @return object|WP_Error the registered post type object, or an error object
*/
function prefix_register_name() {

	$labels = array(
		'name'                => __( 'Strings', 'wpi18n' ),
		'singular_name'       => __( 'String', 'wpi18n' ),
		'add_new'             => _x( 'Add New String', 'wpi18n', 'wpi18n' ),
		'add_new_item'        => __( 'Add New String', 'wpi18n' ),
		'edit_item'           => __( 'Edit String', 'wpi18n' ),
		'new_item'            => __( 'New String', 'wpi18n' ),
		'view_item'           => __( 'View String', 'wpi18n' ),
		'search_items'        => __( 'Search Strings', 'wpi18n' ),
		'not_found'           => __( 'No Strings found', 'wpi18n' ),
		'not_found_in_trash'  => __( 'No Strings found in Trash', 'wpi18n' ),
		'parent_item_colon'   => __( 'Parent String:', 'wpi18n' ),
		'menu_name'           => __( 'Strings', 'wpi18n' ),
	);

	$args = array(
		'labels'                   => $labels,
		'hierarchical'        => false,
		'description'         => 'description',
		'taxonomies'          => array(),
		'public'              => true,
		'show_ui'             => true,
		'show_in_menu'        => true,
		'show_in_admin_bar'   => true,
		'menu_position'       => null,
		'menu_icon'           => null,
		'show_in_nav_menus'   => true,
		'publicly_queryable'  => true,
		'exclude_from_search' => false,
		'has_archive'         => true,
		'query_var'           => true,
		'can_export'          => true,
		'rewrite'             => true,
		'capability_type'     => 'post',
		'supports'            => array(
			'title', 'editor', 'author', 'thumbnail',
			'excerpt','custom-fields', 'trackbacks', 'comments',
			'revisions', 'page-attributes', 'post-formats'
			)
	);

	register_post_type( 'wpi18n', $args );

	
	$labels = array(
		'name'					=> _x( 'Translation Teams', 'Taxonomy Translation Teams', 'text-domain' ),
		'singular_name'			=> _x( 'Translation Team', 'Taxonomy Translation Team', 'text-domain' ),
		'search_items'			=> __( 'Search Translation Teams', 'text-domain' ),
		'popular_items'			=> __( 'Popular Translation Teams', 'text-domain' ),
		'all_items'				=> __( 'All Translation Teams', 'text-domain' ),
		'parent_item'			=> __( 'Parent Translation Team', 'text-domain' ),
		'parent_item_colon'		=> __( 'Parent Translation Team', 'text-domain' ),
		'edit_item'				=> __( 'Edit Translation Team', 'text-domain' ),
		'update_item'			=> __( 'Update Translation Team', 'text-domain' ),
		'add_new_item'			=> __( 'Add New Translation Team', 'text-domain' ),
		'new_item_name'			=> __( 'New Translation Team Name', 'text-domain' ),
		'add_or_remove_items'	=> __( 'Add or remove Translation Teams', 'text-domain' ),
		'choose_from_most_used'	=> __( 'Choose from most used text-domain', 'text-domain' ),
		'menu_name'				=> __( 'Translation Team', 'text-domain' ),
	);

	$args = array(
		'labels'            => $labels,
		'public'            => true,
		'show_in_nav_menus' => true,
		'show_admin_column' => false,
		'hierarchical'      => false,
		'show_tagcloud'     => true,
		'show_ui'           => true,
		'query_var'         => true,
		'rewrite'           => true,
		'query_var'         => true,
		'capabilities'      => array(),
	);

	register_taxonomy( 'wpi18n-teams', array( 'wpi18n' ), $args );

}

add_action( 'init', 'prefix_register_name' );

/**
 * MY CLASS NAME
 *
 * 1. Run `wp wpi18n info`, it will Insert & Update Products
 *
 * @package MY CLASS NAME
 * @since 1.0.0
 */

if( ! class_exists( 'WPI18N' ) && class_exists( 'WP_CLI_Command' ) ) :

	/**
	 * WPI18N
	 *
	 * @since 1.0.0
	 */
	class WPI18N extends WP_CLI_Command {

		/**
		 * Constructor
		 *
		 * @since 1.0.0
		 */
		public function __construct() {
			
		}

		/**
		 * Info
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function info() {

			WP_CLI::line( '***** Silence is Golden. *****' );

		}

		/**
		 * Info
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function download_files() {

			/**
			 * Russian
			 * Русский
			 * ru_RU
			 * Locale Glossary
			 * https://translate.wordpress.org/locale/ru
			 */

			// Translate WordPress, core projects, plugins, and themes into your language. Select your project below to get started.
			$defaults = array(
				'dev',
				'4.8.x',
				'4.7.x',
				'4.6.x',
				'4.5.x',
				'4.4.x',
				'4.3.x',
				'4.2.x',
				'4.1.x',
			);

			if( ! file_exists('po-files') ) {
				mkdir('po-files');
			}
			if( ! file_exists('po-files/wordpress') ) {
				mkdir('po-files/wordpress');
			}

			foreach ($defaults as $key => $directory) {

				if( ! file_exists('po-files/wordpress/'.$directory ) ) {
					mkdir('po-files/wordpress/'.$directory );
				}

				$releases = array(
					'wp/'.$directory.'/ru'              => 'https://translate.wordpress.org/projects/wp/'.$directory.'/ru/default',
					'wp/'.$directory.'/cc/ru'           => 'https://translate.wordpress.org/projects/wp/'.$directory.'/cc/ru/default',
					'wp/'.$directory.'/admin/ru'         => 'https://translate.wordpress.org/projects/wp/'.$directory.'/admin/ru/default',
					'wp/'.$directory.'/admin/network/ru' => 'https://translate.wordpress.org/projects/wp/'.$directory.'/admin/network/ru/default',
				);

				foreach ($releases as $domain => $remote_file_url) {

					// $domain    = 'wp/4.8.x/cc/ru';
					$file      = str_replace('/', '-', $domain);
					// $file_name = $file . '.po';
					$file_name = 'po-files/wordpress/'.$directory.'/'.$file . '.po';

					$request = wp_remote_get( $remote_file_url . '/export-translations' );

					// Is WP Error?
					if ( is_wp_error( $request ) ) {
						WP_CLI::line( $request->get_error_message() );
					}

					// Invalid response code.
					if ( wp_remote_retrieve_response_code( $request ) != 200 ) {
						WP_CLI::line( $request['response'] );
					}

					if( ! is_wp_error( $request ) && wp_remote_retrieve_response_code( $request ) == 200 ) {
						// Get body data.
						$body = wp_remote_retrieve_body( $request );
						WP_CLI::line( 'File created - ' . $file_name . ' from remote file ' . $remote_file_url );

						file_put_contents( $file_name, $body);
					} 

				}
			}


			// https://translate.wordpress.org/projects/wp/dev/ru/default
			// https://translate.wordpress.org/projects/wp/dev/cc/ru/default
			// https://translate.wordpress.org/projects/wp/dev/admin/ru/default
			// https://translate.wordpress.org/projects/wp/dev/admin/network/ru/default

			// https://translate.wordpress.org/projects/wp/4.8.x/ru/default
			// https://translate.wordpress.org/projects/wp/4.8.x/cc/ru/default
			// https://translate.wordpress.org/projects/wp/4.8.x/admin/ru/default
			// https://translate.wordpress.org/projects/wp/4.8.x/admin/network/ru/default

			// https://translate.wordpress.org/projects/wp/4.7.x/ru/default
			// https://translate.wordpress.org/projects/wp/4.7.x/cc/ru/default
			// https://translate.wordpress.org/projects/wp/4.7.x/admin/ru/default
			// https://translate.wordpress.org/projects/wp/4.7.x/admin/network/ru/default

			// https://translate.wordpress.org/projects/wp/4.6.x/ru/default
			// https://translate.wordpress.org/projects/wp/4.6.x/cc/ru/default
			// https://translate.wordpress.org/projects/wp/4.6.x/admin/ru/default
			// https://translate.wordpress.org/projects/wp/4.6.x/admin/network/ru/default

			// https://translate.wordpress.org/projects/wp/4.5.x/ru/default
			// https://translate.wordpress.org/projects/wp/4.5.x/cc/ru/default
			// https://translate.wordpress.org/projects/wp/4.5.x/admin/ru/default
			// https://translate.wordpress.org/projects/wp/4.5.x/admin/network/ru/default

			// https://translate.wordpress.org/projects/wp/4.4.x/ru/default
			// https://translate.wordpress.org/projects/wp/4.4.x/cc/ru/default
			// https://translate.wordpress.org/projects/wp/4.4.x/admin/ru/default
			// https://translate.wordpress.org/projects/wp/4.4.x/admin/network/ru/default

			// https://translate.wordpress.org/projects/wp/4.3.x/ru/default
			// https://translate.wordpress.org/projects/wp/4.3.x/cc/ru/default
			// https://translate.wordpress.org/projects/wp/4.3.x/admin/ru/default
			// https://translate.wordpress.org/projects/wp/4.3.x/admin/network/ru/default

			// https://translate.wordpress.org/projects/wp/4.3.x/ru/default
			// https://translate.wordpress.org/projects/wp/4.3.x/cc/ru/default
			// https://translate.wordpress.org/projects/wp/4.3.x/admin/ru/default
			// https://translate.wordpress.org/projects/wp/4.3.x/admin/network/ru/default

			// https://translate.wordpress.org/projects/wp/4.1.x/ru/default
			// https://translate.wordpress.org/projects/wp/4.1.x/cc/ru/default
			// https://translate.wordpress.org/projects/wp/4.1.x/admin/ru/default
			// https://translate.wordpress.org/projects/wp/4.1.x/admin/network/ru/default

			// ----
			// https://translate.wordpress.org/projects/wp/4.8.x/ru/default/export-translations
			// https://translate.wordpress.org/projects/wp/4.8.x/cc/ru/default/export-translations/wp-4.8.x-cc-ru.po

			// $domain    = 'wp/4.8.x/cc/ru';
			// $file      = str_replace('/', '-', $domain);
			// $file_name = $file . '.po';

			// $request = wp_remote_get( 'https://translate.wordpress.org/projects/'.$domain.'/default/export-translations/' );

			// // Is WP Error?
			// if ( is_wp_error( $request ) ) {
			// 	WP_CLI::error( $request->get_error_message() );
			// }

			// // Invalid response code.
			// if ( wp_remote_retrieve_response_code( $request ) != 200 ) {
			// 	WP_CLI::error( $request['response'] );
			// }

			// // Get body data.
			// $body = wp_remote_retrieve_body( $request );

			// file_put_contents( $file_name, $body);
		}

		/**
		 * Info
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function import() {

			include_once "lib/Gettext/src/autoloader.php";
			include_once "lib/cldr-to-gettext-plural-rules-master/src/autoloader.php";


			// function listFolderFiles($dir){
			//     $ffs = scandir($dir);

			//     unset($ffs[array_search('.', $ffs, true)]);
			//     unset($ffs[array_search('..', $ffs, true)]);

			//     // prevent empty ordered elements
			//     if (count($ffs) < 1)
			//         return;

			//     echo '<ol>';
			//     foreach($ffs as $ff){
			//         echo '<li>'.$ff;
			//         if(is_dir($dir.'/'.$ff)) listFolderFiles($dir.'/'.$ff);
			//         echo '</li>';
			//     }
			//     echo '</ol>';
			// }

			// listFolderFiles('Main Dir');

			//import from a .po file:
			$translations = Translations::fromPoFile( dirname(__FILE__) . '\wp-dev-ru.po' );

			$file_name  = 'bbpress-2.4.x-ru.po';
			$language   = $translations->getHeader( 'Language' );
			$project_id = $translations->getHeader( 'Project-Id-Version' );
			$domain     = $translations->getDomain();

			$line = 1;

			foreach ($translations as $key => $translation) {
				// echo 'getOriginal : ---- ' . $translation->getOriginal() . '<br/>';
				// echo 'getTranslation : ---- ' . $translation->getTranslation() . '<br/>';

				$post_title         = $translation->getOriginal();
				$translation_string = $translation->getTranslation();

				if( ! empty( $post_title ) ) {

					$post_id = post_exists( $post_title );

					if( $post_id ) {
						// Exist.
						WP_CLI::line( $line . ') Exist ' . $post_id . ' for ' . $post_title );

						// Unique key should be: "language_{}_project_{}"
						$translation_key = 'language_'.$language.'_project_'.sanitize_title( $project_id );
						update_post_meta( $post_id, $translation_key, $translation_string );
					} else {
						$new_post = array(
							'post_type'  => 'wpi18n',
							'post_title' => $post_title,
						);
						$post_id = wp_insert_post( $new_post );

						if( ! is_wp_error( $post_id ) ) {
							// insert post meta
							// update_post_meta( $post_id, 'project_id', $project_id );
							// update_post_meta( $post_id, 'language', $language );
							// update_post_meta( $post_id, 'file_name', $file_name );
							// update_post_meta( $post_id, 'domain', $domain );

							// Uniq key should be: "language_{}_project_{}"
							$translation_key = 'language_'.$language.'_project_'.sanitize_title( $project_id );
							update_post_meta( $post_id, $translation_key, $translation_string );

							// Created.
							WP_CLI::line( $line . ') Created ' . $post_id . ' for ' . $post_title );
						} else {
							WP_CLI::line( $line . ') Error ' . $post_id->get_wp_error() );
							WP_CLI::line( 'For ' . $post_id . ' for ' . $post_title );
						}
					}
				} else {
					WP_CLI::line( $post_title );
				}

				$line++;

			}

			WP_CLI::line( '-------------------');
			WP_CLI::line( 'Strings ' . count( $translations ) );
			WP_CLI::line( 'File Name ' . $file_name );
			WP_CLI::line( 'Language ' . $language );
			WP_CLI::line( 'Project ID ' . $project_id );
			WP_CLI::line( 'Domain ' . $domain );

			// //edit some translations:
			// $translation = $translations->find(null, 'apple');

			// if ($translation) {
			// 	$translation->setTranslation('Mazá');
			// }

			// //export to a php array:
			// $translations->toPhpArrayFile('locales/gl.php');

			// //and to a .mo file
			// $translations->toMoFile('Locale/gl/LC_MESSAGES/messages.mo');

		}

	}

	/**
	 * Add Command
	 */
	WP_CLI::add_command( 'wpi18n', 'WPI18N' );

endif;