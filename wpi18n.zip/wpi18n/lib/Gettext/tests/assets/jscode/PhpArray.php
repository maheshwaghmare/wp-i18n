<?php return array (
  'domain' => NULL,
  'plural-forms' => NULL,
  'messages' => 
  array (
    '' => 
    array (
      '' => 
      array (
        0 => 'Content-Transfer-Encoding: 8bit
Content-Type: text/plain; charset=UTF-8
Language: 
Language-Team: 
Last-Translator: 
MIME-Version: 1.0
Project-Id-Version: 
Report-Msgid-Bugs-To: 
',
      ),
      'Value with simple quotes' => 
      array (
        0 => '',
      ),
      'Value with double quotes' => 
      array (
        0 => '',
      ),
      'Other value with double quotes' => 
      array (
        0 => '',
      ),
      'function inside function' => 
      array (
        0 => '',
      ),
      'I can\'t get response.' => 
      array (
        0 => '',
      ),
      'Please, try with other interface type.' => 
      array (
        0 => '',
      ),
      'I can\'t get response. Please, try with other interface type.' => 
      array (
        0 => '',
      ),
    ),
  ),
);