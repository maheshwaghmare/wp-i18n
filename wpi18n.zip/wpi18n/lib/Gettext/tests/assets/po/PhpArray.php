<?php return array (
  'domain' => NULL,
  'plural-forms' => 'nplurals=3; plural=(n==1 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2);',
  'messages' => 
  array (
    '' => 
    array (
      '' => 
      array (
        0 => 'Content-Transfer-Encoding: 8bit
Content-Type: text/plain; charset=UTF-8
Language: 
Language-Team: 
Last-Translator: 
MIME-Version: 1.0
Plural-Forms: nplurals=3; plural=(n==1 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2);
Project-Id-Version: 
Report-Msgid-Bugs-To: 
',
      ),
      'one file' => 
      array (
        0 => '1 plik',
        1 => '2,3,4 pliki',
        2 => '5-21 plików',
      ),
      'single' => 
      array (
        0 => 'test',
      ),
    ),
  ),
);