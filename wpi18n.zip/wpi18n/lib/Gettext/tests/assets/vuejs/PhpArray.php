<?php return array (
  'domain' => NULL,
  'plural-forms' => NULL,
  'messages' => 
  array (
    '' => 
    array (
      '' => 
      array (
        0 => 'Content-Transfer-Encoding: 8bit
Content-Type: text/plain; charset=UTF-8
Language: 
Language-Team: 
Last-Translator: 
MIME-Version: 1.0
Project-Id-Version: 
Report-Msgid-Bugs-To: 
',
      ),
      'js-expr1' => 
      array (
        0 => '',
      ),
      'js-expr2' => 
      array (
        0 => '',
      ),
      'js-alert' => 
      array (
        0 => '',
      ),
      'js-single' => 
      array (
        0 => '',
      ),
      'js-obj-single' => 
      array (
        0 => '',
      ),
      '<span>js-return</span><br>' => 
      array (
        0 => '',
      ),
      't-cond-attribute' => 
      array (
        0 => '',
      ),
      't-attribute' => 
      array (
        0 => '',
      ),
      't-same-line-s' => 
      array (
        0 => '',
      ),
      'multi-occurrence' => 
      array (
        0 => '',
      ),
      't-singular2' => 
      array (
        0 => '',
      ),
      't-v-bind' => 
      array (
        0 => '',
      ),
      't-text' => 
      array (
        0 => '',
      ),
      't-singular' => 
      array (
        0 => '',
      ),
      't-tag' => 
      array (
        0 => '',
      ),
      't-tag-sibling' => 
      array (
        0 => '',
      ),
      't-expr1' => 
      array (
        0 => '',
      ),
      't-expr2' => 
      array (
        0 => '',
      ),
      't-"quotes"' => 
      array (
        0 => '',
      ),
      't-"quotes"-2' => 
      array (
        0 => '',
      ),
      't-\'quotes\'' => 
      array (
        0 => '',
      ),
      't-\'quotes\'-2' => 
      array (
        0 => '',
      ),
      't-spaces-expr' => 
      array (
        0 => '',
      ),
      't-spaces-expr2' => 
      array (
        0 => '',
      ),
      't-p1(parentheses)' => 
      array (
        0 => '',
      ),
    ),
    'some-context' => 
    array (
      'js-action' => 
      array (
        0 => '',
      ),
    ),
    'context' => 
    array (
      't-action' => 
      array (
        0 => '',
      ),
    ),
    'context2' => 
    array (
      't-action2' => 
      array (
        0 => '',
      ),
    ),
  ),
);