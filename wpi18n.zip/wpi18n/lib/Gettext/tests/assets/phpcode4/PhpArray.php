<?php return array (
  'domain' => 'domain1',
  'plural-forms' => NULL,
  'messages' => 
  array (
    '' => 
    array (
      '' => 
      array (
        0 => 'Content-Transfer-Encoding: 8bit
Content-Type: text/plain; charset=UTF-8
Language: 
Language-Team: 
Last-Translator: 
MIME-Version: 1.0
Project-Id-Version: 
Report-Msgid-Bugs-To: 
X-Domain: domain1
',
      ),
      'matching 1' => 
      array (
        0 => '',
      ),
      'matching 2 singular' => 
      array (
        0 => '',
      ),
      'matching 4' => 
      array (
        0 => '',
      ),
    ),
    'context' => 
    array (
      'matching 3 context singular' => 
      array (
        0 => '',
      ),
    ),
  ),
);