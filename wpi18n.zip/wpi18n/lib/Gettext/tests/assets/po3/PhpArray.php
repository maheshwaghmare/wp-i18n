<?php return array (
  'domain' => NULL,
  'plural-forms' => NULL,
  'messages' => 
  array (
    '' => 
    array (
      '' => 
      array (
        0 => 'Content-Transfer-Encoding: 8bit
Content-Type: text/plain; charset=UTF-8
Language: 
Language-Team: 
Last-Translator: 
MIME-Version: 1.0
Project-Id-Version: 
Report-Msgid-Bugs-To: 
',
      ),
      'Dielen' => 
      array (
        0 => 'timber piling floor',
      ),
      'Doppelboden' => 
      array (
        0 => 'double floor',
      ),
      'Estrich' => 
      array (
        0 => 'screed floor',
      ),
      'Fliesen' => 
      array (
        0 => 'flagging',
      ),
      'Kunststoffboden' => 
      array (
        0 => 'synthetic floor',
      ),
      '1 child' => 
      array (
        0 => '1 fillo',
      ),
      '1 comment' => 
      array (
        0 => '1 comentario',
      ),
      '1 star' => 
      array (
        0 => '1 estrela',
      ),
    ),
  ),
);