<?php return array (
  'domain' => NULL,
  'plural-forms' => NULL,
  'messages' => 
  array (
    '' => 
    array (
      '' => 
      array (
        0 => 'Content-Transfer-Encoding: 8bit
Content-Type: text/plain; charset=UTF-8
Language: 
Language-Team: 
Last-Translator: 
MIME-Version: 1.0
Project-Id-Version: 
Report-Msgid-Bugs-To: 
',
      ),
      'text 1' => 
      array (
        0 => '',
      ),
      'text 2' => 
      array (
        0 => '',
      ),
      'text 3 (with parenthesis)' => 
      array (
        0 => '',
      ),
      'text 4 "with double quotes"' => 
      array (
        0 => '',
      ),
      'text 5 \'with escaped single quotes\'' => 
      array (
        0 => '',
      ),
      'text 6' => 
      array (
        0 => '',
      ),
      'text 7 (with parenthesis)' => 
      array (
        0 => '',
      ),
      'text 8 "with escaped double quotes"' => 
      array (
        0 => '',
      ),
      'text 9 \'with single quotes\'' => 
      array (
        0 => '',
      ),
      'text 10 with plural' => 
      array (
        0 => '',
      ),
      '<div id="blog" class="container">
    <div class="row">
        <div class="col-md-12">
            <div id="content">
                <div class="page_post">
                    <div class="container">
                        <div class="margin-top-40"></div>
                        <div class="col-sm-3 col-md-2 centered-xs an-number">4</div>
                    </div>
                </div>
                <div class="container">
                    <h1 class="text-center margin-top-10">Sorry, but we couldn\'t find this page</h1>
                    <div id="body-div">
                        <div id="main-div">
                            <div class="text-404">
                                <div>
                                    <p>Maybe you have entered an incorrect URL of the page or page moved to another section or just page is temporarily unavailable.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>' => 
      array (
        0 => '',
      ),
    ),
    'context' => 
    array (
      'text 1 with context' => 
      array (
        0 => '',
      ),
    ),
  ),
);