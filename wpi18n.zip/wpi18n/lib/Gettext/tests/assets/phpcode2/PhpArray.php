<?php return array (
  'domain' => NULL,
  'plural-forms' => NULL,
  'messages' => 
  array (
    '' => 
    array (
      '' => 
      array (
        0 => 'Content-Transfer-Encoding: 8bit
Content-Type: text/plain; charset=UTF-8
Language: 
Language-Team: 
Last-Translator: 
MIME-Version: 1.0
Project-Id-Version: 
Report-Msgid-Bugs-To: 
',
      ),
      'plain' => 
      array (
        0 => '',
      ),
      'DATE \\a\\t TIME' => 
      array (
        0 => '',
      ),
      'FIELD	FIELD' => 
      array (
        0 => '',
      ),
      'text concatenated with \'comments\'' => 
      array (
        0 => '',
      ),
      'Stop at the variable' => 
      array (
        0 => '',
      ),
      'No comments' => 
      array (
        0 => '',
      ),
      'i18n Tagged comment' => 
      array (
        0 => '',
      ),
      'i18n Tagged comment inside' => 
      array (
        0 => '',
      ),
      'One comment' => 
      array (
        0 => '',
      ),
      'i18n tagged %s' => 
      array (
        0 => '',
      ),
      'foo' => 
      array (
        0 => '',
      ),
      'bar' => 
      array (
        0 => '',
      ),
    ),
    'my-context' => 
    array (
      'All comments' => 
      array (
        0 => '',
      ),
    ),
  ),
);