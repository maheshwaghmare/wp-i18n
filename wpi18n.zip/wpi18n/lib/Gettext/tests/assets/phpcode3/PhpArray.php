<?php return array (
  'domain' => NULL,
  'plural-forms' => NULL,
  'messages' => 
  array (
    '' => 
    array (
      '' => 
      array (
        0 => 'Content-Transfer-Encoding: 8bit
Content-Type: text/plain; charset=UTF-8
Language: 
Language-Team: 
Last-Translator: 
MIME-Version: 1.0
Project-Id-Version: 
Report-Msgid-Bugs-To: 
',
      ),
      'Translation with comments' => 
      array (
        0 => '',
      ),
      'Foo' => 
      array (
        0 => '',
      ),
    ),
  ),
);