<?php return array (
  'domain' => NULL,
  'plural-forms' => NULL,
  'messages' => 
  array (
    '' => 
    array (
      '' => 
      array (
        0 => 'Content-Transfer-Encoding: 8bit
Content-Type: text/plain; charset=UTF-8
Language: 
Language-Team: 
Last-Translator: 
MIME-Version: 1.0
Project-Id-Version: 
Report-Msgid-Bugs-To: 
',
      ),
      'some message' => 
      array (
        0 => '',
      ),
      '%s message' => 
      array (
        0 => '',
      ),
      'my translate 3' => 
      array (
        0 => '',
      ),
    ),
    'some context' => 
    array (
      'some message in a context' => 
      array (
        0 => '',
      ),
    ),
  ),
);