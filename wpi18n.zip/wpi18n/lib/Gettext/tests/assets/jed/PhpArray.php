<?php return array (
  'domain' => 'testingdomain',
  'plural-forms' => 'nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2);',
  'messages' => 
  array (
    '' => 
    array (
      '' => 
      array (
        0 => 'Content-Transfer-Encoding: 8bit
Content-Type: text/plain; charset=UTF-8
Language: bs
Language-Team: 
Last-Translator: 
MIME-Version: 1.0
Plural-Forms: nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2);
Project-Id-Version: 
Report-Msgid-Bugs-To: 
X-Domain: testingdomain
',
      ),
      'Ensure this value has at least %(limit_value)d character (it has %sd).' => 
      array (
        0 => '',
      ),
      'Ensure this value has at most %(limit_value)d character (it has %sd).' => 
      array (
        0 => '',
      ),
      '%ss must be unique for %ss %ss.' => 
      array (
        0 => '%ss mora da bude jedinstven za %ss %ss.',
      ),
      'and' => 
      array (
        0 => 'i',
      ),
      'Value %sr is not a valid choice.' => 
      array (
        0 => '',
      ),
      'This field cannot be null.' => 
      array (
        0 => 'Ovo polje ne može ostati prazno.',
      ),
      'This field cannot be blank.' => 
      array (
        0 => 'Ovo polje ne može biti prazno.',
      ),
      'Field of type: %ss' => 
      array (
        0 => 'Polje tipa: %ss',
      ),
      'Integer' => 
      array (
        0 => 'Cijeo broj',
      ),
      '{test1}' => 
      array (
        0 => 'test1
<div>
 test2
</div>
test3',
      ),
      '{test2}' => 
      array (
        0 => 'test1
<div>
 test2
</div>
test3',
      ),
      'Multibyte test' => 
      array (
        0 => '日本人は日本で話される言語です！',
      ),
      'Tabulation test' => 
      array (
        0 => 'FIELD	FIELD',
      ),
    ),
  ),
);